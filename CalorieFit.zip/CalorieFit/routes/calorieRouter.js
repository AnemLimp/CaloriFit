const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const Calories = require('../models/calories');

var authenticate = require('../authenticate');

const cors = require('./cors');

const calorieRouter = express.Router();

calorieRouter.use(bodyParser.json());

calorieRouter.route('/')
.options(cors.corsWithOptions, (req, res) => { res.sendStatus(200); })
.get(cors.cors, (req,res,next) => {
    Calories.find({})
    .then((Calories) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(Calories);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    Calories.create(req.body)
    .then((calorie) => {
        console.log('calorie Created ', calorie);
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(calorie);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.put(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /Calories');
})
.delete(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    Calories.remove({})
    .then((resp) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(resp);
    }, (err) => next(err))
    .catch((err) => next(err));    
});


calorieRouter.route('/:calorieId')
.options(cors.corsWithOptions, (req, res) => { res.sendStatus(200); })
.get(cors.cors, (req,res,next) => {
    Calories.findById(req.params.calorieId)
    .then((calorie) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(calorie);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    res.statusCode = 403;
    res.end('POST operation not supported on /Calories/'+ req.params.calorieId);
})
.put(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    Calories.findByIdAndUpdate(req.params.calorieId, {
        $set: req.body
    }, { new: true })
    .then((calorie) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(calorie);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.delete(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    Calories.findByIdAndRemove(req.params.calorieId)
    .then((resp) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(resp);
    }, (err) => next(err))
    .catch((err) => next(err));
});

module.exports = calorieRouter;