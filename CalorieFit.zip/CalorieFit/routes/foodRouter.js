const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const foods = require('../models/foods');

var authenticate = require('../authenticate');

const cors = require('./cors');

const foodRouter = express.Router();

foodRouter.use(bodyParser.json());

foodRouter.route('/')
.options(cors.corsWithOptions, (req, res) => { res.sendStatus(200); })
.get(cors.cors, (req,res,next) => {
    foods.find({})
    .populate('comments.author')
    .then((foods) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(foods);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    foods.create(req.body)
    .then((food) => {
        console.log('food Created ', food);
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(food);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.put(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /foods');
})
.delete(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    foods.remove({})
    .then((resp) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(resp);
    }, (err) => next(err))
    .catch((err) => next(err));    
});

foodRouter.route('/:foodId')
.options(cors.corsWithOptions, (req, res) => { res.sendStatus(200); })
.get(cors.cors, (req,res,next) => {
    foods.findById(req.params.foodId)
    .populate('comments.author')
    .then((food) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(food);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    res.statusCode = 403;
    res.end('POST operation not supported on /foods/'+ req.params.foodId);
})
.put(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    foods.findByIdAndUpdate(req.params.foodId, {
        $set: req.body
    }, { new: true })
    .then((food) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(food);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.delete(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    foods.findByIdAndRemove(req.params.foodId)
    .then((resp) => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(resp);
    }, (err) => next(err))
    .catch((err) => next(err));
});

foodRouter.route('/:foodId/comments')
.options(cors.corsWithOptions, (req, res) => { res.sendStatus(200); })
.get(cors.cors, (req,res,next) => {
    foods.findById(req.params.foodId)
    .populate('comments.author')
    .then((food) => {
        if (food != null) {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.json(food.comments);
        }
        else {
            err = new Error('food ' + req.params.foodId + ' not found');
            err.status = 404;
            return next(err);
        }
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    foods.findById(req.params.foodId)
    .then((food) => {
        if (food != null) {
            req.body.author = req.user._id;
            food.comments.push(req.body);
            food.save()
            .then((food) => {
                foods.findById(food._id)
                .populate('comments.author')
                .then((food) => {
                    res.statusCode = 200;
                    res.setHeader('Content-Type', 'application/json');
                    res.json(food);
                })                
            }, (err) => next(err));
        }
        else {
            err = new Error('food ' + req.params.foodId + ' not found');
            err.status = 404;
            return next(err);
        }
    }, (err) => next(err))
    .catch((err) => next(err));
})
.put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403;
    res.end('PUT operation not supported on /foods/'
        + req.params.foodId + '/comments');
})
.delete(cors.corsWithOptions, authenticate.verifyUser, authenticate.verifyAdmin, (req, res, next) => {
    foods.findById(req.params.foodId)
    .then((food) => {
        if (food != null) {
            for (var i = (food.comments.length -1); i >= 0; i--) {
                food.comments.id(food.comments[i]._id).remove();
            }
            food.save()
            .then((food) => {
                res.statusCode = 200;
                res.setHeader('Content-Type', 'application/json');
                res.json(food);                
            }, (err) => next(err));
        }
        else {
            err = new Error('food ' + req.params.foodId + ' not found');
            err.status = 404;
            return next(err);
        }
    }, (err) => next(err))
    .catch((err) => next(err));    
});

foodRouter.route('/:foodId/comments/:commentId')
.options(cors.corsWithOptions, (req, res) => { res.sendStatus(200); })
.get(cors.cors, (req,res,next) => {
    foods.findById(req.params.foodId)
    .populate('comments.author')
    .then((food) => {
        if (food != null && food.comments.id(req.params.commentId) != null) {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.json(food.comments.id(req.params.commentId));
        }
        else if (food == null) {
            err = new Error('food ' + req.params.foodId + ' not found');
            err.status = 404;
            return next(err);
        }
        else {
            err = new Error('Comment ' + req.params.commentId + ' not found');
            err.status = 404;
            return next(err);            
        }
    }, (err) => next(err))
    .catch((err) => next(err));
})
.post(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    res.statusCode = 403;
    res.end('POST operation not supported on /foods/'+ req.params.foodId
        + '/comments/' + req.params.commentId);
})
.put(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    foods.findById(req.params.foodId)
    .then((food) => {
        if (food != null && food.comments.id(req.params.commentId) != null) {
            // Check author before removing food
            if(food.comments.id(req.params.commentId).author.equals(req.user._id)){
                if (req.body.rating) {
                    food.comments.id(req.params.commentId).rating = req.body.rating;
                }
                if (req.body.comment) {
                    food.comments.id(req.params.commentId).comment = req.body.comment;                
                }
                food.save()
                .then((food) => {
                    foods.findById(food._id)
                    .populate('comments.author')
                    .then((food) => {
                        res.statusCode = 200;
                        res.setHeader('Content-Type', 'application/json');
                        res.json(food);  
                    })                 
                }, (err) => next(err));
            }
            else{
                err = new Error('You are not authorized to perform this operation!');
                err.status = 403;
                return next(err);
            }
        }
        else if (food == null) {
            err = new Error('food ' + req.params.foodId + ' not found');
            err.status = 404;
            return next(err);
        }
        else {
            err = new Error('Comment ' + req.params.commentId + ' not found');
            err.status = 404;
            return next(err);            
        }
    }, (err) => next(err))
    .catch((err) => next(err));
})
.delete(cors.corsWithOptions, authenticate.verifyUser, (req, res, next) => {
    foods.findById(req.params.foodId)
    .then((food) => {
        if (food != null && food.comments.id(req.params.commentId) != null) {
            // Check author before removing food
            if(food.comments.id(req.params.commentId).author.equals(req.user._id)){
                food.comments.id(req.params.commentId).remove();
                food.save()
                .then((food) => {
                    foods.findById(food._id)
                    .populate('comments.author')
                    .then((food) => {
                        res.statusCode = 200;
                        res.setHeader('Content-Type', 'application/json');
                        res.json(food);  
                    })                
                }, (err) => next(err));
            }
            else{
                err = new Error('You are not authorized to perform this operation!');
                err.status = 403;
                return next(err);
            }
        }
        else if (food == null) {
            err = new Error('food ' + req.params.foodId + ' not found');
            err.status = 404;
            return next(err);
        }
        else {
            err = new Error('Comment ' + req.params.commentId + ' not found');
            err.status = 404;
            return next(err);            
        }
    }, (err) => next(err))
    .catch((err) => next(err));
});

module.exports = foodRouter;