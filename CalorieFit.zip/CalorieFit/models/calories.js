const mongoose = require('mongoose');
const Schema = mongoose.Schema;

require('mongoose-currency').loadType(mongoose);
const Currency = mongoose.Types.Currency;

var calorieSchema = new Schema({
    percentage:  {
        type: String,
        required: true
    },
    foodItem:  {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Food'
    }
}, {
    timestamps: true
});


var Calories = mongoose.model('Calorie', calorieSchema);

module.exports = Calories;