const mongoose = require('mongoose');
const Schema = mongoose.Schema;

var storiesSchema = new Schema({
    comment:  {
        type: String,
        required: true
    },
    author:  {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }
}, {
    timestamps: true
});

var Stories = mongoose.model('Story', storiesSchema);

module.exports = Stories;